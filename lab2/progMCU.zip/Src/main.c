#include <stdint.h>
#include <stdbool.h>
#include <stm32f446xx.h>

// define директива идентификатор посл-сть символов которые подставляются, макрос на выходе
// define ПРОСТО подставляет символы

#define BITBAND_PERIPH_REF   0x40000000U
#define BITBAND_PERIPH_BASE  0x42000000U
#define PERIPH_BASE          0x40000000U // макрос, содержащий базовый адрес области хранения бит УВВ
// шины
#define AHB1PERIPH_BASE     (PERIPH_BASE + 0x20000U)
// #define APB2PERIPH_BASE     (PERIPH_BASE + 0x10000U)
// GPIO и RCC, и всё содержащее регистры - периферия. GPIOC - конкретный блок периферии
#define GPIOC_BASE          (AHB1PERIPH_BASE + 0x0800U)
#define GPIOD_BASE          (AHB1PERIPH_BASE + 0x0C00U)
// #define RCC_BASE            (AHB1PERIPH_BASE + 0x3800U)
// #define SYSCFG_BASE         (APB2PERIPH_BASE + 0x3800U)
// #define EXTI_BASE           (APB2PERIPH_BASE + 0x3C00U)
// #define TIM2_BASE           (0x40000000U)

// функциональный макрос
#define BITBAND_PERIPH(addr, bit) \ 
    ((volatile uint32_t*)(BITBAND_PERIPH_BASE + ((addr - BITBAND_PERIPH_REF) * 32U) + (bit * 4U)))

#define c13 !(*BITBAND_PERIPH(0x40020810UL, 13))
#define d2 !(*BITBAND_PERIPH(0x40020C10UL, 2))

typedef struct // регистры внутри блока GPIO (регистр - 32-битная ячейка памяти)
{
    uint32_t MODER;    // 0x00
    uint32_t OTYPER;   // 0x04
    uint32_t OSPEEDR;  // 0x08
    uint32_t PUPDR;    // 0x0C
    uint32_t IDR;      // 0x10
    uint32_t ODR;      // 0x14
    uint32_t BSRR;     // 0x18
    uint32_t LCKR;     // 0x1C
    uint32_t AFR[2];   // 0x20-0x24
} GPIO_TypeDef; 

// typedef struct
// {
//     uint32_t CR;            // 0x00
//     uint32_t PLLCFGR;       // 0x04
//     uint32_t CFGR;          // 0x08
//     uint32_t CIR;           // 0x0C
//     uint32_t AHB1RSTR;      // 0x10
//     uint32_t AHB2RSTR;      // 0x14
//     uint32_t AHB3RSTR;      // 0x18
//     uint32_t RESERVED0;     // Reserved, 0x1C
//     uint32_t APB1RSTR;      // 0x20
//     uint32_t APB2RSTR;      // 0x24
//     uint32_t RESERVED1[2];  // Reserved, 0x28-0x2C
//     uint32_t AHB1ENR;       // 0x30
//     uint32_t AHB2ENR;       // 0x34
//     uint32_t AHB3ENR;       // 0x38
//     uint32_t RESERVED2;     // Reserved, 0x3C
//     uint32_t APB1ENR;       // 0x40
//     uint32_t APB2ENR;       // 0x44
//     uint32_t RESERVED3[2];  // Reserved, 0x48-0x4C
//     uint32_t AHB1LPENR;     //
//     uint32_t AHB2LPENR;     // 0x54
//     uint32_t AHB3LPENR;     // 0x58
//     uint32_t RESERVED4;     // Reserved, 0x5C
//     uint32_t APB1LPENR;     // 0x60
//     uint32_t APB2LPENR;     // 0x64
//     uint32_t RESERVED5[2];  // 0x68-0x6C
//     uint32_t BDCR;          // 0x70
//     uint32_t CSR;           // 0x74
//     uint32_t RESERVED6[2];  // 0x78-0x7C
//     uint32_t SSCGR;         // 0x80 
//     uint32_t PLLI2SCFGR;    // 0x84
//     uint32_t PLLSAICFGR;    // 0x88
//     uint32_t DCKCFGR;       // 0x8C
//     uint32_t CKGATENR;      // 0x90
//     uint32_t DCKCFGR2;      // 0x94
// } RCC_TypeDef;

// typedef struct {
//     uint32_t MEMRMP;      // 0x00
//     uint32_t PMC;         // 0x04
//     uint32_t EXTICR[4];   // 0x08-0x14
// } SYSCFG_TypeDef;

// typedef struct {
//     uint32_t EXTI_IMR;      // 0x00
//     uint32_t EXTI_EMR;      // 0x04
//     uint32_t EXTI_RTSR;     // 0x08
//     uint32_t EXTI_FTSR;     // 0x0C
//     uint32_t EXTI_SWIER;    // 0x10
//     uint32_t EXTI_PR;       // 0x14
// } EXTI_TypeDef;

// typedef struct {
//     volatile uint32_t CR1;
//     volatile uint32_t CR2;
//     volatile uint32_t SMCR;
//     volatile uint32_t DIER;
//     volatile uint32_t SR;
//     volatile uint32_t EGR;
//     volatile uint32_t CCMR1;
//     volatile uint32_t CCMR2;
//     volatile uint32_t CCER;
//     volatile uint32_t CNT;
//     volatile uint32_t PSC;
//     volatile uint32_t ARR;
// } TIM_TypeDef;

#define GPIOC   ((GPIO_TypeDef*) GPIOC_BASE) // макрос, возвращающий указатель на структуру GPIO_TypeDef с базовым адресом GPIOC_BASE
// #define RCC     ((RCC_TypeDef*) RCC_BASE)
// #define GPIOD   ((GPIO_TypeDef*) GPIOD_BASE)
// #define SYSCFG  ((SYSCFG_TypeDef *) SYSCFG_BASE)
// #define EXTI    ((EXTI_TypeDef *) EXTI_BASE)
// #define TIM2    ((TIM_TypeDef*) TIM2_BASE)

bool c13Flag = false;
bool d2Flag = false;

// для обработки дребезга
volatile uint8_t debounceActive = 0;
volatile uint8_t buttonPressed = 0;

void EXTI15_10_IRQHandler(void)
// обработчик прерывания по нажатии на кнопки
{
    if (EXTI->PR & (1 << 12)) {
        EXTI->PR = (1 << 12); // Сброс флага
        c13Flag = true;
    }
    if (EXTI->PR & (1 << 13)) {
        EXTI->PR = (1 << 13);
        d2Flag = true;
    }
}


int main(void)
{
    RCC->AHB1ENR |= 0xC; // 0xC = 0b1100, Включаем тактирование на 2 и 3 бит с нашим параметром (порты C и D)
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; // тактирование SYSCFG (для EXTI)
    GPIOC->MODER |= 0x555500; // 4-11 пины порта GPIOC (диоды) в output

    GPIOC->MODER &= ~(3UL << (13 * 2));         // 00: Input
    GPIOD->MODER &= ~(3UL << (2 * 2));

    GPIOC->PUPDR &= ~(0x3 << (13 * 2));         // Сначала очищаем биты 26 и 27
    GPIOC->PUPDR |= (0x1 << (13 * 2));          // 01 - Pull-up
    GPIOD->PUPDR &= ~(0x3 << (2 * 2));
    GPIOD->PUPDR |= (0x1 << (2 * 2));

    // Мультиплексор альтернативной функции: из какого порта (GPIOA, GPIOB, GPIOC...) должен браться сигнал для конкретной линии внешнего прерывания
    // EXTICR - массив регистров настройки внешних прерываний, EXTICR[3] - регистр с 4 настройками
    SYSCFG->EXTICR[3] &= 0x0; // Сначала очищаем
    SYSCFG->EXTICR[3] |= (0x0010); // GPIOC в EXTI12 (в прерывание по 12 линии)
    SYSCFG->EXTICR[3] |= (0x0011 << (4)); // GPIOD в EXTI13
    
    // Разрешаем линии 12 и 13 EXTI
    EXTI->IMR  |= (0x1 << 12) | (0x1 << 13);   // Unmask interrupt, разрешает контроллеру EXTI реагировать на изменения сигналов с этих пинов
    EXTI->FTSR |= (0x1 << 12) | (0x1 << 13);   // По спаду (falling edge)
    EXTI->RTSR &= ~((0x1 << 12) | (0x1 << 13));// одновременно падающий и возрастающий фронт на кнопке? надо убрать по идее, не будет такой ситуации

    NVIC_EnableIRQ(EXTI15_10_IRQn);  // Линии 10–15 обслуживаются этим IRQ

    GPIOC->BSRR = 0x10; // зажигаем светодиод на PC4
    while(1) {
        bool buttonPressed = c13 | d2; // bit-banding функц макрос
        uint32_t bits = GPIOC->ODR;

        if (c13Flag) {
            if (bits == 0x800) {
                GPIOC->BSRR = bits << 16; // сдвигаем влево значения битов 0:15 регистра, теперь те же биты расположены по адресам 16:31, а это уже не относится к данным портов. 
                GPIOC->BSRR = 0x10;
            } else {
                GPIOC->BSRR = bits << 16; // тут именно bits надо сдвигать на 16, а не что-то ещё - в BSRR 16-31 биты за сброс позиции регистра данных GPIO отвечают, недостаточно просто сбросить 0-15 биты
                GPIOC->BSRR = bits << 1;
            }
            for (int i = 0; i < 500000; i++) {} // обработка дребезга контактов
        elif (d2Flag) {
            if (bits == 0x10) {
                GPIOC->BSRR = bits << 16;
                GPIOC->BSRR = 0x800;
            } else {
                GPIOC->BSRR = bits << 16;
                GPIOC->BSRR = bits >> 1; // сдвиг вправо
            }
            for (int i = 0; i < 500000; i++) {}
            }
        }
    }
}
